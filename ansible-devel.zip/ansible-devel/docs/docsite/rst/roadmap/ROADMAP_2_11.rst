.. _base_roadmap_2_11:

=================
Ansible-base 2.11
=================

.. contents::
   :local:

Release Schedule
----------------

Expected
========

PRs must be raised well in advance of the dates below to have a chance of being included in this ansible-base release.

.. note:: There is no Alpha phase in 2.11.
.. note:: Dates subject to change.

- ????-??-?? Beta 1 **Feature freeze**
  No new functionality (including modules/plugins) to any code

- ????-??-?? Release Candidate 1
- ????-??-?? Release Candidate 2
- ????-??-?? Release Candidate 3
- ????-??-?? Release Candidate 4
- ????-??-?? Release

Release Manager
---------------

 TBD

Planned work
============
