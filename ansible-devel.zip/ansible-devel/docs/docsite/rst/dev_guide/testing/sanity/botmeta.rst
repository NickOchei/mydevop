botmeta
=======

Verifies that ``./github/BOTMETA.yml`` is valid.
